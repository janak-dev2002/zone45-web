// blog.jsx — Notes & case studies listing.

const POSTS = [
  { date: "2026-05-12", read: "9 min", tags: ["case-study", "iot"], featured: true,
    title: "Cutting alarm latency from fourteen minutes to forty-three seconds",
    excerpt: "How we rebuilt Northbridge Telemetry's pager chain end-to-end without touching the existing ESP32 field nodes. A breakdown of every stage of the path, what we threw out, and why we kept MQTT in the middle." },
  { date: "2026-04-29", read: "6 min", tags: ["agents", "workflow"],
    title: "A studio of one, with a team of agents",
    excerpt: "What our agent-assisted workflow actually looks like, day to day: which agents we use, where they're allowed to write to disk, and the audit trail we hand clients at the end of every engagement." },
  { date: "2026-04-08", read: "11 min", tags: ["case-study", "stripe"],
    title: "Migrating 22k subscriptions to a new biller with zero downtime",
    excerpt: "Faulkner Studio outgrew its Rails monolith. We cut over to Stripe + Postgres + Next.js across one weekend with a four-stage rollback path. Here's the runbook, edited only lightly." },
  { date: "2026-03-21", read: "4 min", tags: ["opinion"],
    title: "Boring technology, kept boring",
    excerpt: "On the discipline of picking a stack that hasn't moved in two years, and refusing to upgrade until you have a reason measured in dollars or pages." },
  { date: "2026-02-14", read: "8 min", tags: ["mobile", "react-native"],
    title: "Shipping an iPad app to MDM in nine weeks",
    excerpt: "Stockwell Health's pharmacist app, from PRD to TestFlight. Offline-first SQLite, an OAuth flow that survives 4G dropouts, and the trick to passing App Store review on the first try." },
  { date: "2026-01-30", read: "5 min", tags: ["billing", "policy"],
    title: "Why we still quote a fixed price",
    excerpt: "Time-and-materials is the agency model. It rewards the wrong things. Here's how a one-person studio scopes a fixed-fee engagement, and what we put in the SOW to make it stick." },
  { date: "2026-01-09", read: "7 min", tags: ["infra"],
    title: "One Pi, twelve services, sixty days uptime",
    excerpt: "A working pattern for putting an entire small-business backend on a single Raspberry Pi 5: nginx, Postgres, Caddy, Tailscale, fail2ban, and a backup story you can explain." },
];

const ALL_BLOG_TAGS = ["All", "case-study", "iot", "agents", "stripe", "mobile", "opinion", "infra"];

function BlogPage({ mobile = false }) {
  const [tag, setTag] = React.useState("All");
  const filtered = tag === "All" ? POSTS : POSTS.filter(p => p.tags.includes(tag));
  const featured = filtered.find(p => p.featured) || filtered[0];
  const rest = filtered.filter(p => p !== featured);

  return (
    <div className={"page " + (mobile ? "mobile" : "desktop")}>
      {mobile ? <MNav active="notes"/> : <Nav active="notes"/>}
      <section className="band">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Notes · case studies · runbooks</span>
            <h1 className="h1">What we learned, written down.</h1>
            <p className="lead">Long-form post-mortems from real engagements, plus shorter notes on tooling
              and process. New entries about once a month.</p>
          </div>

          {/* Filter row */}
          <div style={{ display: "flex", alignItems: mobile ? "flex-start" : "center",
            justifyContent: "space-between", gap: 16,
            flexDirection: mobile ? "column" : "row",
            paddingBottom: 24, marginBottom: 32,
            borderBottom: "1px solid #3d3a39" }}>
            <div className="row gap-2" style={{ alignItems: "center" }}>
              <Icon name="filter" size={16} color="#8b949e"/>
              <span className="caption" style={{ color: "#8b949e", letterSpacing: 1.2,
                textTransform: "uppercase", fontWeight: 600 }}>Filter by tag</span>
            </div>
            <div className="chips">
              {ALL_BLOG_TAGS.map(t => (
                <button key={t} className={"chip " + (tag === t ? "active" : "")}
                  onClick={() => setTag(t)}>{t === "All" ? t : "#" + t}</button>
              ))}
            </div>
          </div>

          {/* Featured */}
          {featured && (
            <article className="card card--featured" style={{ padding: mobile ? 24 : 40, marginBottom: 32 }}>
              <div className="row gap-3" style={{ alignItems: "center", marginBottom: 16, flexWrap: "wrap" }}>
                <span className="pill pill-live mono" style={{ fontSize: 11 }}>Featured · most-read</span>
                <span className="caption mono" style={{ color: "#8b949e" }}>{featured.date} · {featured.read} read</span>
              </div>
              <h2 className="h2" style={{ fontSize: mobile ? 26 : 36, marginBottom: 16, textWrap: "balance",
                lineHeight: mobile ? "32px" : "44px" }}>{featured.title}</h2>
              <p className="lead" style={{ marginBottom: 20 }}>{featured.excerpt}</p>
              <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                {featured.tags.map(t => <span key={t} className="chip-static">#{t}</span>)}
              </div>
            </article>
          )}

          {/* Post list */}
          <div>
            {rest.map((p, i) => (
              <article className="post" key={i}>
                <div>
                  <div className="post-date">{p.date}</div>
                  <div className="caption" style={{ color: "#6b6664", marginTop: 2 }}>{p.read} read</div>
                </div>
                <div>
                  <h3 className="post-title">{p.title}</h3>
                  <p className="post-excerpt">{p.excerpt}</p>
                  <div className="post-tags">
                    {p.tags.map(t => <span key={t} className="chip-static">#{t}</span>)}
                  </div>
                </div>
                {!mobile && (
                  <div style={{ alignSelf: "center", color: "#6b6664" }}>
                    <Icon name="arrow" size={18}/>
                  </div>
                )}
              </article>
            ))}
            <div className="hr-solid"/>
          </div>

          {/* RSS / feed footer */}
          <div style={{ marginTop: 40, display: "flex",
            flexDirection: mobile ? "column" : "row",
            justifyContent: "space-between", alignItems: mobile ? "flex-start" : "center",
            gap: 12, padding: 20, border: "1px dashed rgba(79,93,117,0.4)", borderRadius: 8 }}>
            <div className="col gap-2">
              <span className="body-strong">New notes by email</span>
              <span className="small">No newsletter. Two paragraphs, once a month. Unsubscribe at the bottom.</span>
            </div>
            <div className="row gap-2" style={{ width: mobile ? "100%" : "auto" }}>
              <input className="field" placeholder="you@example.com" style={{ minWidth: mobile ? "auto" : 260, flex: mobile ? 1 : "none" }}/>
              <button className="btn btn-primary btn-sm">Subscribe</button>
            </div>
          </div>
        </div>
      </section>
      <Footer mobile={mobile}/>
    </div>
  );
}

Object.assign(window, { BlogPage });
