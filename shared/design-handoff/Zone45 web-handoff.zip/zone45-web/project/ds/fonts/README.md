# Fonts

This folder is where self-hosted webfont binaries (`.woff2`) live. The system declares `@font-face` rules in `../colors_and_type.css` that point at:

- `Inter-Regular.woff2` · `Inter-Medium.woff2` · `Inter-SemiBold.woff2` · `Inter-Bold.woff2`
- `JetBrainsMono-Regular.woff2` · `JetBrainsMono-Medium.woff2` · `JetBrainsMono-Bold.woff2`

## ⚠ Substitution flag

The brand specification calls for **Inter** + **SF Mono**.
- **Inter** ships under the OFL and can be self-hosted directly — get it from <https://rsms.me/inter/>.
- **SF Mono** is an Apple-system font and cannot be redistributed. We substitute **JetBrains Mono** (OFL, free) which is a near-perfect match for the brand's monospaced role. Get it from <https://www.jetbrains.com/lp/mono/>.

If real `.woff2` files are not yet on disk, every HTML file in this system also imports both faces via **Google Fonts** as a fallback (`fonts.css` adjacent to this folder). The Google-served Inter and JetBrains Mono will render identically to the self-hosted versions on every modern browser; drop in the `.woff2` files when you want fully offline behaviour.

**Action item for the user:** if you want full offline self-hosting, drop the `.woff2` files into this folder with the exact filenames listed above and remove the `<link>` to `fonts.css` from your HTML.
