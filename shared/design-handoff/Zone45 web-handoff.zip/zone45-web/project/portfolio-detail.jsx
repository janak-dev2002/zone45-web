// portfolio-detail.jsx — Single project detail page.

function PortfolioDetailPage({ mobile = false }) {
  const p = PROJECTS[0]; // Northbridge
  return (
    <div className={"page " + (mobile ? "mobile" : "desktop")}>
      {mobile ? <MNav active="work"/> : <Nav active="work"/>}

      <section className="band">
        <div className="container">
          {/* Breadcrumb */}
          <div className="row gap-2" style={{ alignItems: "center", marginBottom: 28, color: "#6b6664" }}>
            <a href="#work" className="caption mono" style={{ color: "#bdbdbd" }}>Work</a>
            <span className="caption mono">/</span>
            <span className="caption mono">{p.client.toLowerCase().replace(/\s+/g, "-")}</span>
          </div>

          {/* Header */}
          <div className="col gap-5" style={{ maxWidth: 880, marginBottom: 40 }}>
            <div className="row gap-3" style={{ alignItems: "center", flexWrap: "wrap" }}>
              <span className="eyebrow">{p.client}</span>
              <span className="caption" style={{ color: "#3d3a39" }}>·</span>
              <span className="caption">{p.sector}</span>
              <span className="caption" style={{ color: "#3d3a39" }}>·</span>
              <span className="caption mono">{p.year}</span>
              <span className="pill pill-live mono" style={{ fontSize: 11, marginLeft: "auto" }}>Live in production</span>
            </div>
            <h1 className="h1" style={{ textWrap: "balance" }}>{p.title}</h1>
            <p className="lead">A custom telemetry stack for a grain-storage operator running 480 wireless
              moisture sensors across 14 silos. Replaced an off-the-shelf SCADA dashboard that took
              fourteen minutes to alarm. Now alarms in under a minute, on the phones of three people who care.</p>
          </div>

          {/* Quick facts strip */}
          <div className="stat-grid" style={{ marginBottom: mobile ? 32 : 56 }}>
            <div className="stat"><span className="stat-num">480</span><span className="stat-label">sensors live</span></div>
            <div className="stat"><span className="stat-num">&lt; 60s</span><span className="stat-label">alarm latency</span></div>
            <div className="stat"><span className="stat-num">18mo</span><span className="stat-label">uptime, no resets</span></div>
            <div className="stat"><span className="stat-num">14wk</span><span className="stat-label">brief → cutover</span></div>
          </div>

          {/* Hero image */}
          <div style={{ aspectRatio: mobile ? "4 / 3" : "16 / 8", background: "#0a0a0a",
            border: "1px solid #3d3a39", borderRadius: 8, position: "relative", overflow: "hidden",
            marginBottom: mobile ? 40 : 64 }}>
            <DetailHero/>
            <div style={{ position: "absolute", bottom: 14, left: 16, display: "flex", gap: 8 }}>
              <span className="codechip" style={{ fontSize: 11 }}>fleet.northbridge.farm</span>
              <span className="codechip" style={{ fontSize: 11 }}>v2.4.1</span>
            </div>
            <div style={{ position: "absolute", top: 14, right: 16, display: "flex", gap: 6 }}>
              <span className="caption mono" style={{ color: "#6b6664" }}>// hero · dashboard view</span>
            </div>
          </div>

          {/* Body: two columns */}
          <div className="g-2-narrow" style={{ marginBottom: mobile ? 40 : 64 }}>
            <div className="col gap-5">
              <span className="eyebrow">The brief</span>
              <h2 className="h2" style={{ fontSize: mobile ? 24 : 32, lineHeight: mobile ? "30px" : "40px" }}>
                Fourteen-minute alarms were getting people fired.
              </h2>
              <p className="body">Northbridge ran a fleet of wireless sensors across fourteen silos, piped
                into a vendor SCADA dashboard. When a sensor saw moisture spike, the warning chain ran
                through MQTT → vendor cloud → an email gateway → an SMS service. Median time-to-pager was
                fourteen minutes. Two recent spoilage events traced back to delays in that chain.</p>
              <p className="body">They asked for a system where any operator could see every silo on one
                screen, and where alarms reached the right phone in under a minute.</p>

              <span className="eyebrow" style={{ marginTop: 24 }}>What we built</span>
              <h2 className="h2" style={{ fontSize: mobile ? 24 : 32, lineHeight: mobile ? "30px" : "40px" }}>
                A direct path from sensor to phone.
              </h2>
              <p className="body">We kept the existing ESP32-based sensor nodes — they're fine. Replaced
                everything above them. A small MQTT broker sits on a Pi at each site. Telemetry pushes to
                InfluxDB on a managed host. Next.js + WebSocket renders the dashboard. Alarms fire through
                a single PagerDuty integration, with deduplication and a 45-second budget.</p>
              <p className="body">The whole thing fits in three repositories and one Terraform module.
                The operator dashboard works on the warehouse iPad and an office laptop. The on-call
                rotation is three people. The pager has gone off 41 times in 18 months — every alarm was real.</p>
            </div>

            {/* Side rail */}
            <aside className="col gap-5">
              <div className="card" style={{ padding: 22 }}>
                <span className="caption" style={{ color: "#8b949e", letterSpacing: 1.2,
                  textTransform: "uppercase", fontWeight: 600 }}>Stack</span>
                <div className="row" style={{ flexWrap: "wrap", gap: 6, marginTop: 12 }}>
                  {["TypeScript", "Next.js 14", "InfluxDB 2", "Postgres", "ESP32 (existing)", "MQTT",
                    "Cloudflare", "Fly.io", "PagerDuty", "Terraform"].map(s => (
                    <span key={s} className="codechip" style={{ fontSize: 11 }}>{s}</span>
                  ))}
                </div>
              </div>
              <div className="card" style={{ padding: 22 }}>
                <span className="caption" style={{ color: "#8b949e", letterSpacing: 1.2,
                  textTransform: "uppercase", fontWeight: 600 }}>Engagement</span>
                <dl style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
                  {[["Duration", "14 weeks"], ["Model", "Fixed-fee"], ["Team", "1 + client PM"],
                    ["Handover", "Repos + IaC"], ["Support", "12 months SLA"]].map(([k, v]) => (
                    <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 16 }}>
                      <dt className="small" style={{ color: "#8b949e" }}>{k}</dt>
                      <dd className="small mono" style={{ color: "#f2f2f2" }}>{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
              <div className="card card--featured" style={{ padding: 22 }}>
                <span className="caption mono" style={{ color: "#00d992" }}>// testimonial</span>
                <p className="body" style={{ marginTop: 12, color: "#f2f2f2", fontSize: 15,
                  fontStyle: "italic", lineHeight: "23px" }}>
                  &ldquo;Three people, one rotation, no more spoilage write-offs. The first invoice paid for itself in nine weeks.&rdquo;
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 16 }}>
                  <div className="avatar">EH</div>
                  <div>
                    <div className="body-strong" style={{ fontSize: 13 }}>Elena Halverson</div>
                    <div className="caption">COO, Northbridge Telemetry</div>
                  </div>
                </div>
              </div>
            </aside>
          </div>

          {/* Architecture diagram band */}
          <div style={{ borderTop: "1px solid #3d3a39", paddingTop: 48, marginBottom: mobile ? 32 : 56 }}>
            <div className="section-head">
              <span className="eyebrow">Architecture</span>
              <h2 className="h2" style={{ fontSize: mobile ? 24 : 32 }}>From sensor to pager, in one diagram.</h2>
            </div>
            <ArchDiagram mobile={mobile}/>
          </div>

          {/* Result band */}
          <div className="hr-green" style={{ marginBottom: 48 }}></div>
          <div className="g-2" style={{ marginBottom: mobile ? 32 : 56 }}>
            <div className="col gap-4">
              <span className="eyebrow">Outcome</span>
              <h2 className="h2" style={{ fontSize: mobile ? 24 : 32 }}>Fourteen minutes → forty-three seconds.</h2>
            </div>
            <div className="col gap-3">
              {[
                ["Median alarm time-to-pager", "14m 12s → 43s"],
                ["Spoilage events post-cutover", "0 in 18 months"],
                ["Operator dashboard load time", "5.4s → 380ms"],
                ["Annual SCADA license retired", "$28,400 / yr"],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between",
                  gap: 16, borderBottom: "1px dashed rgba(79,93,117,0.4)", paddingBottom: 12 }}>
                  <span className="body" style={{ color: "#bdbdbd" }}>{k}</span>
                  <span className="mono" style={{ color: "#00d992", fontSize: 14 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Next project */}
          <div style={{ borderTop: "1px solid #3d3a39", paddingTop: 32,
            display: "flex", justifyContent: "space-between", alignItems: "center",
            flexDirection: mobile ? "column" : "row", gap: 16 }}>
            <a href="#work" className="row gap-3" style={{ alignItems: "center", color: "#bdbdbd" }}>
              <Icon name="arrowLeft" size={16}/>
              <span className="small">All work</span>
            </a>
            <a href="#" className="row gap-3" style={{ alignItems: "center" }}>
              <div className="col" style={{ alignItems: "flex-end", gap: 4 }}>
                <span className="caption mono" style={{ color: "#6b6664" }}>Next project · 02 / 06</span>
                <span className="body-strong">Stockwell Health — iPad app →</span>
              </div>
            </a>
          </div>
        </div>
      </section>
      <Footer mobile={mobile}/>
    </div>
  );
}

function DetailHero() {
  // A mock "dashboard hero" with KPIs + a line chart + a sparkline grid.
  return (
    <svg viewBox="0 0 1200 540" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
      <rect width="1200" height="540" fill="#0a0a0a"/>
      {/* Top bar */}
      <rect x="0" y="0" width="1200" height="56" fill="#101010" stroke="#3d3a39"/>
      <circle cx="20" cy="28" r="4" fill="#00d992"/>
      <text x="34" y="32" fontFamily="JetBrains Mono" fontSize="13" fill="#f2f2f2">fleet.northbridge.farm</text>
      <rect x="1080" y="16" width="100" height="24" rx="4" fill="#1a1a1a" stroke="#3d3a39"/>
      <text x="1098" y="32" fontFamily="JetBrains Mono" fontSize="11" fill="#bdbdbd">all silos ↓</text>
      {/* KPI row */}
      {[["480", "sensors online", 30], ["14", "silos", 200], ["3", "active alerts", 370], ["43s", "median alarm", 540]].map(([n, l, x], i) => (
        <g key={i} transform={`translate(${x}, 84)`}>
          <text fontFamily="JetBrains Mono" fontSize="28" fill="#f2f2f2" fontWeight="500">{n}</text>
          <text y="22" fontFamily="Inter" fontSize="12" fill="#8b949e">{l}</text>
        </g>
      ))}
      {/* Big chart */}
      <g transform="translate(30, 170)">
        <rect width="780" height="320" rx="8" fill="#101010" stroke="#3d3a39"/>
        <text x="20" y="30" fontFamily="Inter" fontSize="13" fill="#f2f2f2" fontWeight="600">Moisture · last 24h · silo B-04</text>
        <text x="20" y="50" fontFamily="JetBrains Mono" fontSize="11" fill="#8b949e">threshold: 14.2%</text>
        {[80, 140, 200, 260].map(y => <line key={y} x1="20" y1={y} x2="760" y2={y} stroke="#1a1a1a"/>)}
        {/* threshold */}
        <line x1="20" y1="130" x2="760" y2="130" stroke="#3d3a39" strokeDasharray="3 5"/>
        <text x="730" y="125" fontFamily="JetBrains Mono" fontSize="10" fill="#6b6664">14.2</text>
        {/* line */}
        <path d="M20 240 L80 230 L140 220 L200 200 L260 190 L320 200 L380 180 L440 160 L500 130 L560 110 L620 90 L680 110 L740 95"
          stroke="#00d992" strokeWidth="2" fill="none"/>
        <path d="M20 240 L80 230 L140 220 L200 200 L260 190 L320 200 L380 180 L440 160 L500 130 L560 110 L620 90 L680 110 L740 95 L740 290 L20 290 Z"
          fill="#00d992" opacity="0.06"/>
        {/* alarm marker */}
        <circle cx="560" cy="110" r="6" fill="#00d992"/>
        <circle cx="560" cy="110" r="12" fill="#00d992" opacity=".15"/>
        <text x="572" y="105" fontFamily="JetBrains Mono" fontSize="10" fill="#00d992">alarm fired 09:42</text>
      </g>
      {/* Sparkline column */}
      <g transform="translate(840, 170)">
        <rect width="330" height="320" rx="8" fill="#101010" stroke="#3d3a39"/>
        <text x="20" y="30" fontFamily="Inter" fontSize="13" fill="#f2f2f2" fontWeight="600">Silos · live</text>
        {Array.from({ length: 6 }).map((_, i) => (
          <g key={i} transform={`translate(20, ${56 + i * 44})`}>
            <text fontFamily="JetBrains Mono" fontSize="11" fill="#bdbdbd">B-0{i+1}</text>
            <text x="46" y="0" fontFamily="JetBrains Mono" fontSize="11" fill="#6b6664">{(11 + i * 0.4).toFixed(1)}%</text>
            <path d={`M100 -2 L130 ${-3 + (i % 3)} L160 ${-1 + (i % 2)} L190 ${-5 + (i % 4)} L220 ${-3 - (i % 3)} L250 ${-2 + (i % 2)} L280 ${-4 - (i % 2)}`}
              stroke={i === 2 ? "#00d992" : "#3d3a39"} strokeWidth="1.5" fill="none"/>
            <circle cx="290" cy={-4} r="3" fill={i === 2 ? "#00d992" : (i === 4 ? "#ef4444" : "#3d3a39")}/>
          </g>
        ))}
      </g>
    </svg>
  );
}

function ArchDiagram({ mobile }) {
  return (
    <div style={{ border: "1px solid #3d3a39", borderRadius: 8, padding: mobile ? 16 : 32,
      background: "#0a0a0a" }}>
      <svg viewBox="0 0 1200 280" width="100%" preserveAspectRatio="xMidYMid meet">
        {/* Nodes */}
        {[
          ["480 ESP32 nodes", "field", 80, 100, "#00d992"],
          ["Pi MQTT broker (×4)", "site", 320, 100],
          ["InfluxDB 2.x", "cloud · fly.io", 560, 60],
          ["Postgres 16", "cloud · fly.io", 560, 160],
          ["Next.js + WS API", "edge · cloudflare", 820, 100],
          ["PagerDuty + iOS", "humans", 1060, 100, "#00d992"],
        ].map(([title, sub, x, y, accent], i) => (
          <g key={i} transform={`translate(${x - 90}, ${y - 30})`}>
            <rect width="180" height="64" rx="6"
              fill="#101010" stroke={accent || "#3d3a39"} strokeWidth={accent ? 2 : 1}/>
            <text x="14" y="26" fontFamily="Inter" fontSize="13" fill="#f2f2f2" fontWeight="600">{title}</text>
            <text x="14" y="46" fontFamily="JetBrains Mono" fontSize="11" fill="#8b949e">{sub}</text>
          </g>
        ))}
        {/* Arrows */}
        {[
          [170, 100, 230, 100], [410, 100, 470, 80], [410, 100, 470, 160],
          [650, 80, 730, 100], [650, 160, 730, 100], [910, 100, 970, 100]
        ].map(([x1, y1, x2, y2], i) => (
          <g key={i}>
            <line x1={x1} y1={y1} x2={x2 - 6} y2={y2} stroke="#3d3a39" strokeWidth="1.5"/>
            <path d={`M${x2-6} ${y2 - 4} L${x2} ${y2} L${x2-6} ${y2 + 4}`} fill="#3d3a39"/>
          </g>
        ))}
        {/* Labels */}
        <text x="200" y="92" fontFamily="JetBrains Mono" fontSize="10" fill="#6b6664" textAnchor="middle">LoRa</text>
        <text x="440" y="60" fontFamily="JetBrains Mono" fontSize="10" fill="#6b6664" textAnchor="middle">MQTT</text>
        <text x="690" y="60" fontFamily="JetBrains Mono" fontSize="10" fill="#6b6664" textAnchor="middle">flux query</text>
        <text x="940" y="92" fontFamily="JetBrains Mono" fontSize="10" fill="#6b6664" textAnchor="middle">webhook</text>
      </svg>
    </div>
  );
}

Object.assign(window, { PortfolioDetailPage });
