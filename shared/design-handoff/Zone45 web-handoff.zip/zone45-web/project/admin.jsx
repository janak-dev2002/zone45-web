// admin.jsx — Login screen + dashboard with sidebar nav + portfolio CRUD table.

function AdminLoginPage({ mobile = false }) {
  const [show, setShow] = React.useState(false);
  return (
    <div className={"page " + (mobile ? "mobile" : "desktop")} style={{ minHeight: "100%" }}>
      <div className="auth-shell">
        {/* Left brand panel — hidden on mobile */}
        <aside className="auth-side">
          <div>
            <Wordmark/>
            <div style={{ marginTop: 48 }}>
              <span className="eyebrow">Studio admin · v2026.05</span>
              <h1 className="h1" style={{ fontSize: 44, lineHeight: "48px", marginTop: 18 }}>
                Internal console.
              </h1>
              <p className="lead" style={{ marginTop: 16, maxWidth: 360 }}>
                CMS for the public site, intake queue, and project ledger. Not a SaaS — single tenant, single user.
              </p>
            </div>
          </div>
          <div className="code-block" style={{ maxWidth: 380 }}>
            <div className="caption mono" style={{ color: "#6b6664", marginBottom: 8 }}>// session</div>
            <div><span style={{ color: "#8b949e" }}>$</span> <span style={{ color: "#00d992" }}>jwt</span> sign --aud=admin --ttl=2h</div>
            <div style={{ color: "#8b949e", marginTop: 4 }}>→ token issued, 2h expiry</div>
            <div style={{ color: "#8b949e" }}>→ device cookie: hardened (HttpOnly · SameSite=strict)</div>
          </div>
        </aside>

        {/* Login card */}
        <main className="auth-main">
          <form className="auth-form" onSubmit={e => e.preventDefault()}>
            {mobile && <div style={{ marginBottom: 12 }}><Wordmark size={22}/></div>}
            <div className="row gap-3" style={{ alignItems: "center", justifyContent: "space-between" }}>
              <span className="eyebrow">Sign in</span>
              <span className="codechip" style={{ fontSize: 11 }}>POST /auth</span>
            </div>
            <h2 className="h2" style={{ fontSize: 30, lineHeight: "36px" }}>Studio admin</h2>
            <p className="small" style={{ color: "#bdbdbd", marginTop: -10 }}>
              JWT auth · single user · two-hour session.
            </p>

            <div className="form-row" style={{ marginTop: 8 }}>
              <label className="field-label">Email</label>
              <div style={{ position: "relative" }}>
                <input className="field" type="email" placeholder="mara@zoneforty5.studio"
                  defaultValue="mara@zoneforty5.studio"
                  style={{ paddingLeft: 38 }}/>
                <div style={{ position: "absolute", left: 12, top: 0, bottom: 0,
                  display: "flex", alignItems: "center", color: "#6b6664" }}>
                  <Icon name="mail" size={16}/>
                </div>
              </div>
            </div>
            <div className="form-row">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                <label className="field-label">Password</label>
                <a href="#" className="caption" style={{ color: "#2fd6a1" }}>Forgot?</a>
              </div>
              <div style={{ position: "relative" }}>
                <input className="field" type={show ? "text" : "password"}
                  placeholder="••••••••••••" defaultValue="hunter2hunter2"
                  style={{ paddingLeft: 38, paddingRight: 44 }}/>
                <div style={{ position: "absolute", left: 12, top: 0, bottom: 0,
                  display: "flex", alignItems: "center", color: "#6b6664" }}>
                  <Icon name="lock" size={16}/>
                </div>
                <button type="button" className="icon-btn"
                  onClick={() => setShow(!show)}
                  style={{ position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)" }}
                  aria-label={show ? "Hide password" : "Show password"}>
                  <Icon name={show ? "eyeOff" : "eye"} size={16}/>
                </button>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <label className="row gap-2" style={{ alignItems: "center", cursor: "pointer" }}>
                <input type="checkbox" defaultChecked style={{ accentColor: "#00d992", width: 14, height: 14 }}/>
                <span className="small" style={{ color: "#bdbdbd" }}>Trust this device for 7 days</span>
              </label>
              <span className="caption mono" style={{ color: "#6b6664" }}>2FA · TOTP</span>
            </div>

            <button type="submit" className="btn btn-primary" style={{ width: "100%" }}>
              Sign in →
            </button>

            <div style={{ paddingTop: 16, borderTop: "1px dashed rgba(79,93,117,0.4)",
              display: "flex", justifyContent: "space-between", gap: 12 }}>
              <span className="caption" style={{ color: "#6b6664" }}>
                <Icon name="lock" size={12} color="#6b6664"/> &nbsp;TLS 1.3 · jwt-rs256
              </span>
              <span className="caption mono" style={{ color: "#6b6664" }}>build a1f3d2e</span>
            </div>
          </form>
        </main>
      </div>
    </div>
  );
}

// -----------------------------
// Admin Dashboard
// -----------------------------

const ADMIN_PROJECTS = [
  { id: "northbridge", title: "Northbridge Telemetry — Fleet dashboard", client: "Northbridge",
    sector: "IoT", year: 2024, slug: "/work/northbridge", status: "live", updated: "2026-05-12",
    views: 1842, featured: true },
  { id: "stockwell",  title: "Stockwell Health — iPad app",             client: "Stockwell",
    sector: "Mobile", year: 2024, slug: "/work/stockwell", status: "live", updated: "2026-05-04",
    views: 1207, featured: true },
  { id: "faulkner",   title: "Faulkner Studio — Billing portal",        client: "Faulkner",
    sector: "Web", year: 2023, slug: "/work/faulkner", status: "live", updated: "2026-04-28",
    views: 980 },
  { id: "verglas",    title: "Verglas Ops — Internal console",          client: "Verglas",
    sector: "Web", year: 2023, slug: "/work/verglas", status: "live", updated: "2026-04-19",
    views: 612 },
  { id: "ostara",     title: "Ostara Logistics — Dispatch + driver",    client: "Ostara",
    sector: "Mobile", year: 2023, slug: "/work/ostara", status: "live", updated: "2026-03-30",
    views: 540 },
  { id: "halverson",  title: "Halverson Climate — Soil-moisture mesh",  client: "Halverson",
    sector: "IoT", year: 2022, slug: "/work/halverson", status: "draft", updated: "2026-02-14",
    views: 0 },
  { id: "newcase",    title: "Untitled draft — Trafalgar fintech audit", client: "Trafalgar",
    sector: "Audit", year: 2026, slug: "/work/trafalgar-draft", status: "draft", updated: "2026-05-22",
    views: 0 },
  { id: "rivermill",  title: "Rivermill Mills — Cancelled (NDA)",       client: "Rivermill",
    sector: "Web", year: 2022, slug: "/work/rivermill", status: "archived", updated: "2025-12-01",
    views: 32 },
];

function AdminDashboardPage({ mobile = false }) {
  const [sel, setSel] = React.useState(new Set(["faulkner"]));
  const [filter, setFilter] = React.useState("All");
  const visible = filter === "All" ? ADMIN_PROJECTS :
    ADMIN_PROJECTS.filter(p => p.status === filter.toLowerCase());

  const toggle = (id) => {
    const next = new Set(sel);
    next.has(id) ? next.delete(id) : next.add(id);
    setSel(next);
  };

  return (
    <div className={"page " + (mobile ? "mobile" : "desktop")} style={{ minHeight: "100%" }}>
      <div className="admin">
        {!mobile && <AdminSidebar active="portfolio"/>}
        <div>
          <AdminTopbar mobile={mobile}/>
          <main className="adm-main">
            {/* Breadcrumb + heading */}
            <div className="row gap-2" style={{ alignItems: "center", marginBottom: 12, color: "#6b6664" }}>
              <span className="caption mono">admin</span>
              <span className="caption mono">/</span>
              <span className="caption mono" style={{ color: "#bdbdbd" }}>portfolio</span>
            </div>
            <div style={{ display: "flex",
              flexDirection: mobile ? "column" : "row",
              justifyContent: "space-between", alignItems: mobile ? "flex-start" : "center",
              gap: 16, marginBottom: 24 }}>
              <div>
                <h1 className="h2" style={{ fontSize: mobile ? 22 : 26 }}>Portfolio</h1>
                <p className="small" style={{ marginTop: 4 }}>
                  {ADMIN_PROJECTS.length} projects · {ADMIN_PROJECTS.filter(p => p.status === "live").length} live
                </p>
              </div>
              <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                <button className="btn btn-outline btn-sm">
                  <Icon name="search" size={14}/> Search
                </button>
                <button className="btn btn-outline btn-sm">Import CSV</button>
                <button className="btn btn-primary btn-sm">
                  <Icon name="plus" size={14}/> New project
                </button>
              </div>
            </div>

            {/* Stats */}
            <div className="stat-grid" style={{ marginBottom: 24 }}>
              <div className="stat">
                <span className="stat-num">14</span>
                <span className="stat-label">total projects</span>
                <span className="stat-delta">+1 this month</span>
              </div>
              <div className="stat">
                <span className="stat-num">2</span>
                <span className="stat-label">drafts in queue</span>
                <span className="stat-delta">+1 today</span>
              </div>
              <div className="stat">
                <span className="stat-num">7.4k</span>
                <span className="stat-label">page views · 30d</span>
                <span className="stat-delta">+12%</span>
              </div>
              <div className="stat">
                <span className="stat-num">23</span>
                <span className="stat-label">intakes · open</span>
                <span className="stat-delta down">-3 vs prev</span>
              </div>
            </div>

            {/* Filter row */}
            <div style={{ display: "flex", justifyContent: "space-between",
              flexDirection: mobile ? "column" : "row",
              alignItems: mobile ? "flex-start" : "center", gap: 12, marginBottom: 16 }}>
              <div className="chips">
                {["All", "Live", "Draft", "Archived"].map(f => (
                  <button key={f} className={"chip " + (filter === f ? "active" : "")}
                    onClick={() => setFilter(f)}>{f}</button>
                ))}
              </div>
              {!mobile && (
                <div className="row gap-3" style={{ alignItems: "center" }}>
                  {sel.size > 0 ? (
                    <>
                      <span className="caption mono" style={{ color: "#00d992" }}>{sel.size} selected</span>
                      <button className="btn btn-outline btn-sm">Bulk publish</button>
                      <button className="btn btn-outline btn-sm" style={{ color: "#ef4444",
                        borderColor: "rgba(239,68,68,0.3)" }}>Archive</button>
                    </>
                  ) : (
                    <span className="caption" style={{ color: "#6b6664" }}>
                      Sort · <span className="mono" style={{ color: "#bdbdbd" }}>updated ↓</span>
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Table (desktop) or stacked cards (mobile) */}
            {mobile ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {visible.map(p => <AdminProjectCard key={p.id} p={p}/>)}
              </div>
            ) : (
              <table className="tbl">
                <thead>
                  <tr>
                    <th style={{ width: 32 }}>
                      <input type="checkbox" style={{ accentColor: "#00d992", width: 14, height: 14 }}/>
                    </th>
                    <th>Project</th>
                    <th style={{ width: 110 }}>Sector</th>
                    <th style={{ width: 110 }}>Status</th>
                    <th style={{ width: 130 }}>Updated</th>
                    <th style={{ width: 110 }}>Views</th>
                    <th style={{ width: 110 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map(p => (
                    <tr key={p.id} style={{ background: sel.has(p.id) ? "rgba(0,217,146,0.04)" : "transparent" }}>
                      <td>
                        <input type="checkbox" checked={sel.has(p.id)}
                          onChange={() => toggle(p.id)}
                          style={{ accentColor: "#00d992", width: 14, height: 14 }}/>
                      </td>
                      <td>
                        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                          <div style={{ width: 40, height: 28, borderRadius: 4, background: "#1a1a1a",
                            border: "1px solid #3d3a39", display: "flex", alignItems: "center",
                            justifyContent: "center" }}>
                            <span className="caption mono" style={{ color: "#6b6664", fontSize: 10 }}>
                              {p.client.slice(0, 3).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="body-strong" style={{ fontSize: 14, color: "#f2f2f2" }}>{p.title}</div>
                            <div className="caption mono" style={{ color: "#6b6664" }}>{p.slug} · {p.year}</div>
                          </div>
                          {p.featured && <span className="codechip" style={{ fontSize: 10,
                            background: "rgba(0,217,146,0.08)", color: "#00d992" }}>featured</span>}
                        </div>
                      </td>
                      <td className="mono">{p.sector}</td>
                      <td>
                        <span className="row gap-2" style={{ alignItems: "center", textTransform: "capitalize" }}>
                          <span className={"status-dot " + p.status}></span>
                          {p.status}
                        </span>
                      </td>
                      <td className="mono">{p.updated}</td>
                      <td className="mono">{p.views.toLocaleString()}</td>
                      <td>
                        <div className="row gap-2">
                          <button className="icon-btn" aria-label="View"><Icon name="eye" size={14}/></button>
                          <button className="icon-btn" aria-label="Edit"><Icon name="edit" size={14}/></button>
                          <button className="icon-btn danger" aria-label="Delete"><Icon name="trash" size={14}/></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {/* Footer / pagination */}
            <div style={{ display: "flex",
              flexDirection: mobile ? "column" : "row",
              justifyContent: "space-between", alignItems: mobile ? "flex-start" : "center",
              gap: 12, marginTop: 16 }}>
              <span className="caption mono" style={{ color: "#6b6664" }}>
                Showing {visible.length} of {ADMIN_PROJECTS.length}
              </span>
              <div className="row gap-2" style={{ alignItems: "center" }}>
                <button className="btn btn-outline btn-sm">← Prev</button>
                <span className="caption mono" style={{ color: "#bdbdbd" }}>page 1 / 1</span>
                <button className="btn btn-outline btn-sm">Next →</button>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

function AdminSidebar({ active }) {
  return (
    <aside className="adm-side">
      <div className="adm-side-head">
        <Wordmark size={20}/>
        <span className="codechip" style={{ marginLeft: "auto", fontSize: 10 }}>admin</span>
      </div>
      <nav className="adm-nav">
        <div className="adm-nav-section">Studio</div>
        {[
          { id: "dash",      label: "Dashboard",  icon: "grid" },
          { id: "portfolio", label: "Portfolio",  icon: "layers" },
          { id: "notes",     label: "Notes",      icon: "pen" },
          { id: "intakes",   label: "Intakes",    icon: "mail",   badge: "3" },
        ].map(l => (
          <a key={l.id} className={l.id === active ? "active" : ""}>
            <Icon name={l.icon} size={16}/>
            <span style={{ flex: 1 }}>{l.label}</span>
            {l.badge && (
              <span style={{ background: "#00d992", color: "#0a0a0a", fontSize: 10,
                fontFamily: "JetBrains Mono, monospace", padding: "1px 6px",
                borderRadius: 9999, fontWeight: 600 }}>{l.badge}</span>
            )}
          </a>
        ))}
        <div className="adm-nav-section">Operations</div>
        {[
          { id: "agents",   label: "Agents",      icon: "smart" },
          { id: "deploys",  label: "Deploys",     icon: "rocket" },
          { id: "logs",     label: "Logs",        icon: "activity" },
          { id: "settings", label: "Settings",    icon: "settings" },
        ].map(l => (
          <a key={l.id} className={l.id === active ? "active" : ""}>
            <Icon name={l.icon} size={16}/>
            <span style={{ flex: 1 }}>{l.label}</span>
          </a>
        ))}
      </nav>
      <div style={{ marginTop: 16, padding: "12px 16px", borderTop: "1px solid #3d3a39",
        display: "flex", alignItems: "center", gap: 10 }}>
        <div className="avatar" style={{ width: 30, height: 30, fontSize: 12 }}>MH</div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="small" style={{ color: "#f2f2f2", fontWeight: 500 }}>Mara Halvorsen</div>
          <div className="caption mono" style={{ color: "#6b6664", overflow: "hidden",
            textOverflow: "ellipsis", whiteSpace: "nowrap" }}>mara@zoneforty5.studio</div>
        </div>
      </div>
    </aside>
  );
}

function AdminTopbar({ mobile }) {
  return (
    <header className="adm-top">
      {mobile ? (
        <div className="row gap-3" style={{ alignItems: "center" }}>
          <div className="mnav-burger"><Icon name="menu" size={16} color="#f2f2f2"/></div>
          <Wordmark size={18}/>
        </div>
      ) : (
        <div className="row gap-3" style={{ alignItems: "center" }}>
          <div style={{ position: "relative" }}>
            <input className="field" placeholder="Search projects, intakes, notes…"
              style={{ width: 320, paddingLeft: 36, height: 36, fontSize: 13 }}/>
            <div style={{ position: "absolute", left: 12, top: 0, bottom: 0,
              display: "flex", alignItems: "center", color: "#6b6664" }}>
              <Icon name="search" size={14}/>
            </div>
            <span className="kbd" style={{ position: "absolute", right: 10, top: "50%",
              transform: "translateY(-50%)" }}>⌘K</span>
          </div>
        </div>
      )}
      <div className="row gap-3" style={{ alignItems: "center" }}>
        <span className="pill pill-live mono" style={{ fontSize: 11 }}>prod · all systems go</span>
        {!mobile && (
          <button className="icon-btn" aria-label="Notifications">
            <Icon name="bell" size={16}/>
          </button>
        )}
        <div className="avatar" style={{ width: 32, height: 32, fontSize: 12 }}>MH</div>
      </div>
    </header>
  );
}

function AdminProjectCard({ p }) {
  return (
    <div style={{ background: "#101010", border: "1px solid #3d3a39", borderRadius: 8, padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, marginBottom: 8 }}>
        <span className="row gap-2" style={{ alignItems: "center", textTransform: "capitalize", fontSize: 13 }}>
          <span className={"status-dot " + p.status}></span>
          {p.status}
        </span>
        <span className="caption mono" style={{ color: "#6b6664" }}>{p.updated}</span>
      </div>
      <div className="body-strong" style={{ fontSize: 14, marginBottom: 4 }}>{p.title}</div>
      <div className="caption mono" style={{ color: "#6b6664", marginBottom: 12 }}>{p.slug} · {p.sector} · {p.views} views</div>
      <div className="row gap-2">
        <button className="icon-btn"><Icon name="eye" size={14}/></button>
        <button className="icon-btn"><Icon name="edit" size={14}/></button>
        <button className="icon-btn danger"><Icon name="trash" size={14}/></button>
      </div>
    </div>
  );
}

Object.assign(window, { AdminLoginPage, AdminDashboardPage });
