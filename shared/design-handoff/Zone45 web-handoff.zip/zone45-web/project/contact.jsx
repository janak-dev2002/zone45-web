// contact.jsx — Contact form + submission note + side meta.

function ContactPage({ mobile = false }) {
  const [submitted, setSubmitted] = React.useState(false);
  const [form, setForm] = React.useState({ name: "", email: "", subject: "Full-stack web", message: "" });
  const update = k => e => setForm({ ...form, [k]: e.target.value });

  const charsLeft = 800 - form.message.length;

  return (
    <div className={"page " + (mobile ? "mobile" : "desktop")}>
      {mobile ? <MNav active="contact"/> : <Nav active="contact"/>}

      <section className="band">
        <div className="container">
          <div className="g-2-wide">
            {/* Left rail */}
            <div className="col gap-5">
              <span className="eyebrow">Contact · Q3 2026 intake</span>
              <h1 className="h1" style={{ fontSize: mobile ? 38 : 56, lineHeight: mobile ? "42px" : "60px" }}>
                Tell me what's broken. I'll tell you what it takes to fix it.
              </h1>
              <p className="lead">Submit the form and you'll hear back inside one business day with one of
                three answers: (a) a 30-minute call, (b) a referral to someone better-fit, or (c) a polite
                no with a reason.</p>

              <div style={{ marginTop: 16, padding: 24, border: "1px solid #3d3a39",
                borderRadius: 8, background: "#0a0a0a", display: "flex",
                flexDirection: "column", gap: 14 }}>
                {[
                  ["Pager", "hi@zoneforty5.studio", "mail"],
                  ["Signal", "On request after intake", "lock"],
                  ["PGP", "key.zoneforty5.studio/mara.asc", "lock"],
                  ["Response window", "1 business day", "activity"],
                ].map(([k, v, icon]) => (
                  <div key={k} style={{ display: "flex", alignItems: mobile ? "flex-start" : "center",
                    flexDirection: mobile ? "column" : "row",
                    justifyContent: "space-between",
                    gap: mobile ? 4 : 16, paddingBottom: 10,
                    borderBottom: "1px dashed rgba(79,93,117,0.4)" }}>
                    <span className="row gap-3" style={{ alignItems: "center" }}>
                      <Icon name={icon} size={14} color="#00d992"/>
                      <span className="caption" style={{ color: "#8b949e",
                        letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 600 }}>{k}</span>
                    </span>
                    <span className="mono small" style={{ color: "#f2f2f2",
                      wordBreak: "break-all", overflowWrap: "anywhere" }}>{v}</span>
                  </div>
                ))}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between",
                  gap: 16 }}>
                  <span className="row gap-3" style={{ alignItems: "center" }}>
                    <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#00d992",
                      boxShadow: "0 0 0 3px rgba(0,217,146,0.18)" }}/>
                    <span className="caption" style={{ color: "#8b949e",
                      letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 600 }}>Next slot</span>
                  </span>
                  <span className="mono small" style={{ color: "#00d992" }}>Q3 2026 · closes 14 Aug</span>
                </div>
              </div>

              {!mobile && (
                <div className="code-block" style={{ marginTop: 16 }}>
                  <div className="caption mono" style={{ color: "#6b6664", marginBottom: 8 }}>// what a good first message looks like</div>
                  <div style={{ color: "#bdbdbd" }}>1. who you are &amp; what you make</div>
                  <div style={{ color: "#bdbdbd" }}>2. the thing that's broken or missing</div>
                  <div style={{ color: "#bdbdbd" }}>3. when you need it shipped</div>
                  <div style={{ color: "#bdbdbd" }}>4. budget range, even a rough one</div>
                </div>
              )}
            </div>

            {/* Form */}
            <div className="card" style={{ padding: mobile ? 24 : 36 }}>
              {submitted ? (
                <SubmittedNote form={form} onReset={() => { setSubmitted(false); }}/>
              ) : (
                <form onSubmit={e => { e.preventDefault(); setSubmitted(true); }}
                  style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                  <div className="row gap-3" style={{ alignItems: "center", justifyContent: "space-between", flexWrap: "wrap" }}>
                    <span className="codechip">POST /intake</span>
                    <span className="mono caption" style={{ color: "#6b6664" }}>id: intake.2026.q3</span>
                  </div>

                  <div className="form-grid">
                    <div className="form-row">
                      <label className="field-label">Name</label>
                      <input className="field" placeholder="Casey Falter" value={form.name} onChange={update("name")} required/>
                    </div>
                    <div className="form-row">
                      <label className="field-label">Email</label>
                      <input className="field" type="email" placeholder="you@company.com"
                        value={form.email} onChange={update("email")} required/>
                    </div>
                  </div>

                  <div className="form-row">
                    <label className="field-label">Subject</label>
                    <div style={{ position: "relative" }}>
                      <select className="field" value={form.subject} onChange={update("subject")}
                        style={{ appearance: "none", paddingRight: 38 }}>
                        {["Full-stack web", "IoT / embedded", "Mobile (iOS / Android)",
                          "Audit or review", "Speaking / press", "Something else"].map(o =>
                          <option key={o} value={o}>{o}</option>)}
                      </select>
                      <div style={{ position: "absolute", right: 12, top: 0, bottom: 0,
                        display: "flex", alignItems: "center", pointerEvents: "none", color: "#8b949e" }}>
                        <Icon name="chevDown" size={16}/>
                      </div>
                    </div>
                  </div>

                  <div className="form-row">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <label className="field-label">Message</label>
                      <span className="caption mono" style={{ color: charsLeft < 80 ? "#ef4444" : "#6b6664" }}>
                        {charsLeft} chars left
                      </span>
                    </div>
                    <textarea className="field"
                      placeholder="Tell me about the system you want shipped. Include a rough timeline and budget if you have one."
                      value={form.message} onChange={update("message")}
                      rows={6} maxLength={800}/>
                  </div>

                  <div className="form-row">
                    <label className="field-label">Budget range</label>
                    <div className="chips">
                      {["< €15k", "€15 — 40k", "€40 — 80k", "€80k+", "Tell me"].map((b, i) => (
                        <button key={b} type="button" className={"chip " + (i === 1 ? "active" : "")}>{b}</button>
                      ))}
                    </div>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: 10,
                    padding: 12, border: "1px dashed rgba(79,93,117,0.4)", borderRadius: 6 }}>
                    <input type="checkbox" id="gdpr" defaultChecked
                      style={{ accentColor: "#00d992", width: 16, height: 16 }}/>
                    <label htmlFor="gdpr" className="small" style={{ color: "#bdbdbd", lineHeight: "20px" }}>
                      I understand my message is read by Mara only and deleted within 30 days if we don't engage.
                    </label>
                  </div>

                  <div style={{ display: "flex",
                    flexDirection: mobile ? "column" : "row",
                    gap: 12, justifyContent: "space-between", alignItems: mobile ? "stretch" : "center",
                    paddingTop: 8, borderTop: "1px solid #3d3a39" }}>
                    <span className="caption mono" style={{ color: "#6b6664" }}>
                      Encrypted in transit · TLS 1.3 · No tracking
                    </span>
                    <button type="submit" className="btn btn-primary">Send intake →</button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
      <Footer mobile={mobile}/>
    </div>
  );
}

function SubmittedNote({ form, onReset }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div className="row gap-3" style={{ alignItems: "center", justifyContent: "space-between" }}>
        <span className="codechip" style={{ background: "rgba(0,217,146,0.1)", color: "#00d992" }}>
          200 OK · received
        </span>
        <span className="mono caption" style={{ color: "#6b6664" }}>req: intake.f8a2c1</span>
      </div>
      <div style={{ width: 48, height: 48, borderRadius: 8, background: "rgba(0,217,146,0.08)",
        border: "1px solid rgba(0,217,146,0.3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon name="check" size={22} color="#00d992"/>
      </div>
      <h2 className="h2" style={{ fontSize: 28 }}>Thanks{form.name ? `, ${form.name.split(" ")[0]}` : ""}. We'll be in touch.</h2>
      <p className="body">Your intake is sitting in <span className="codechip" style={{ fontSize: 12 }}>inbox/q3-2026</span>.
        Expect a reply at <span className="codechip" style={{ fontSize: 12 }}>{form.email || "your email"}</span> within one business day.</p>
      <div style={{ background: "#0a0a0a", border: "1px dashed rgba(79,93,117,0.4)",
        borderRadius: 8, padding: 16, fontFamily: "JetBrains Mono, monospace", fontSize: 13,
        color: "#bdbdbd", lineHeight: "22px" }}>
        <div><span style={{ color: "#6b6664" }}>$</span> <span style={{ color: "#00d992" }}>queue</span> intake.add --priority=normal</div>
        <div style={{ color: "#8b949e" }}>→ stored · awaiting human triage</div>
        <div style={{ color: "#8b949e" }}>→ next sweep · today 17:00 CET</div>
      </div>
      <div className="row gap-3" style={{ marginTop: 8 }}>
        <a className="btn btn-outline btn-sm" href="#work">Read selected work →</a>
        <button className="btn btn-ghost btn-sm" onClick={onReset}>Send another</button>
      </div>
    </div>
  );
}

Object.assign(window, { ContactPage });
