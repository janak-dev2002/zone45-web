// portfolio.jsx — Project listing with tech-stack filter chips.

const PROJECTS = [
  { id: "northbridge", num: "01", client: "Northbridge Telemetry", year: "2024",
    sector: "Industrial IoT", title: "A fleet dashboard for 480 grain-silo sensors",
    body: "Replaced an off-the-shelf dashboard with a custom Next.js + InfluxDB stack. Alarm latency cut from 14 minutes to under 60 seconds.",
    stack: ["Next.js", "InfluxDB", "ESP32", "MQTT"], featured: true,
    chart: "line" },
  { id: "stockwell", num: "02", client: "Stockwell Health", year: "2024",
    sector: "Mobile health", title: "Pharmacist-facing iPad app, App-Store reviewed",
    body: "PRD to TestFlight in nine weeks. Offline-first inventory sync, ePrescription scanning, MDM-deployed to 60 sites.",
    stack: ["React Native", "Swift", "Postgres"], chart: "grid" },
  { id: "faulkner", num: "03", client: "Faulkner Studio", year: "2023",
    sector: "Full-stack web", title: "A subscription billing portal that didn't melt",
    body: "Stripe + Postgres + edge-cached Next.js. Replaced an in-house Rails monolith. Migrated 22k customers with zero downtime.",
    stack: ["Next.js", "Postgres", "Stripe", "Cloudflare"], chart: "bars" },
  { id: "verglas", num: "04", client: "Verglas Ops", year: "2023",
    sector: "Internal tools", title: "An ops console for a 12-person remote team",
    body: "React + TanStack + Postgres. Replaced three SaaS subscriptions with one workspace. Onboarded the team in an afternoon.",
    stack: ["React", "TanStack", "Postgres"], chart: "kanban" },
  { id: "ostara", num: "05", client: "Ostara Logistics", year: "2023",
    sector: "Logistics", title: "A driver-app + dispatch pair for last-mile delivery",
    body: "React Native driver app paired with a Next.js dispatch console. Live route updates over WebSocket, GPX export for compliance.",
    stack: ["React Native", "Next.js", "WebSocket"], chart: "map" },
  { id: "halverson", num: "06", client: "Halverson Climate", year: "2022",
    sector: "Industrial IoT", title: "A wireless soil-moisture mesh for 40 hectares",
    body: "Custom RP2040 firmware on LoRaWAN, MQTT gateway to a Grafana dashboard. 18 months in the field, no battery swaps.",
    stack: ["RP2040", "MQTT", "Grafana"], chart: "sparkline" },
];

const ALL_TAGS = ["All", "Next.js", "React Native", "ESP32", "Postgres", "Stripe", "InfluxDB", "Swift", "MQTT"];

function PortfolioPage({ mobile = false }) {
  const [tag, setTag] = React.useState("All");
  const visible = tag === "All" ? PROJECTS : PROJECTS.filter(p => p.stack.includes(tag));
  return (
    <div className={"page " + (mobile ? "mobile" : "desktop")}>
      {mobile ? <MNav active="work"/> : <Nav active="work"/>}
      <section className="band">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Selected work · 2022 → 2026</span>
            <h1 className="h1">Fourteen production systems. Six worth showing.</h1>
            <p className="lead">Every one of these is still running today. References available on request — every client is on the call.</p>
          </div>

          <div style={{ display: "flex", alignItems: mobile ? "flex-start" : "center",
            justifyContent: "space-between", gap: 16,
            flexDirection: mobile ? "column" : "row",
            paddingBottom: 24, marginBottom: 32,
            borderBottom: "1px solid #3d3a39" }}>
            <div className="row gap-3" style={{ alignItems: "center" }}>
              <Icon name="filter" size={16} color="#8b949e"/>
              <span className="caption" style={{ color: "#8b949e", letterSpacing: 1.2,
                textTransform: "uppercase", fontWeight: 600 }}>Filter by stack</span>
            </div>
            <div className="chips">
              {ALL_TAGS.map(t => (
                <button key={t} className={"chip " + (tag === t ? "active" : "")}
                  onClick={() => setTag(t)}>{t}</button>
              ))}
            </div>
          </div>

          <div className="g-2">
            {visible.map(p => <ProjectCard key={p.id} p={p}/>)}
          </div>

          {visible.length === 0 && (
            <div style={{ padding: 64, textAlign: "center", color: "#6b6664",
              border: "1px dashed #3d3a39", borderRadius: 8 }}>
              <div className="mono" style={{ fontSize: 13 }}>// no projects match #{tag}</div>
              <button className="btn btn-outline btn-sm" style={{ marginTop: 16 }}
                onClick={() => setTag("All")}>Reset filter</button>
            </div>
          )}
        </div>
      </section>
      <Footer mobile={mobile}/>
    </div>
  );
}

function ProjectCard({ p }) {
  return (
    <article className="proj">
      <div className="proj-thumb">
        <span className="proj-thumb-num">// {p.num}</span>
        <ProjectThumb kind={p.chart}/>
        <div style={{ position: "absolute", top: 14, right: 14 }}>
          {p.featured && <span className="pill pill-live mono" style={{ fontSize: 11 }}>Featured</span>}
        </div>
      </div>
      <div className="proj-body">
        <div className="proj-meta">
          <span className="caption mono" style={{ color: "#00d992" }}>{p.client}</span>
          <span className="caption" style={{ color: "#3d3a39" }}>·</span>
          <span className="caption">{p.sector}</span>
          <span style={{ marginLeft: "auto" }} className="caption mono">{p.year}</span>
        </div>
        <h3 className="h3" style={{ textWrap: "balance", fontSize: 22, lineHeight: "28px" }}>{p.title}</h3>
        <p className="body" style={{ fontSize: 14, lineHeight: "22px" }}>{p.body}</p>
        <div className="row" style={{ flexWrap: "wrap", gap: 6, marginTop: "auto", paddingTop: 8 }}>
          {p.stack.map(s => (<span key={s} className="codechip" style={{ fontSize: 11, padding: "2px 7px" }}>{s}</span>))}
        </div>
      </div>
    </article>
  );
}

// Procedural project-thumbnail "art" — abstract data-viz placeholders that fit the brand.
function ProjectThumb({ kind }) {
  const w = "100%", h = "100%";
  if (kind === "line") {
    return (
      <svg viewBox="0 0 320 180" width={w} height={h} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        {[40, 80, 120].map(y => <line key={y} x1="0" y1={y} x2="320" y2={y} stroke="#3d3a39" strokeDasharray="2 4"/>)}
        <path d="M0 140 L40 120 L80 130 L120 90 L160 100 L200 60 L240 75 L280 50 L320 65"
          stroke="#00d992" strokeWidth="2" fill="none"/>
        <path d="M0 140 L40 120 L80 130 L120 90 L160 100 L200 60 L240 75 L280 50 L320 65 L320 180 L0 180 Z"
          fill="url(#gradLine)" opacity=".3"/>
        <defs>
          <linearGradient id="gradLine" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#00d992" stopOpacity=".6"/>
            <stop offset="100%" stopColor="#00d992" stopOpacity="0"/>
          </linearGradient>
        </defs>
      </svg>
    );
  }
  if (kind === "grid") {
    const rows = 5, cols = 9;
    return (
      <svg viewBox="0 0 320 180" width={w} height={h} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        {Array.from({ length: rows }).map((_, r) => Array.from({ length: cols }).map((_, c) => {
          const lit = ((r * 7 + c * 3) % 5 === 0);
          return <rect key={r + "-" + c} x={30 + c * 28} y={28 + r * 24} width="20" height="16" rx="2"
            fill={lit ? "#00d992" : "#1a1a1a"} stroke="#3d3a39" strokeWidth="1"/>;
        }))}
      </svg>
    );
  }
  if (kind === "bars") {
    return (
      <svg viewBox="0 0 320 180" width={w} height={h} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        <line x1="20" y1="150" x2="300" y2="150" stroke="#3d3a39"/>
        {[60, 90, 50, 120, 70, 130, 100, 140, 80, 110].map((bh, i) => (
          <rect key={i} x={28 + i * 28} y={150 - bh} width="18" height={bh}
            fill={i === 7 ? "#00d992" : "#1a1a1a"} stroke="#3d3a39"/>
        ))}
      </svg>
    );
  }
  if (kind === "kanban") {
    return (
      <svg viewBox="0 0 320 180" width={w} height={h} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        {[0, 1, 2].map(c => (
          <g key={c} transform={`translate(${20 + c * 100}, 20)`}>
            <rect x="0" y="0" width="80" height="140" fill="#0a0a0a" stroke="#3d3a39" rx="4"/>
            <rect x="8" y="10" width="64" height="3" fill={c === 1 ? "#00d992" : "#3d3a39"}/>
            {[0, 1, 2, 3].map(r => (
              <rect key={r} x="8" y={22 + r * 28} width="64" height="20" fill="#1a1a1a" stroke="#3d3a39" rx="2"/>
            ))}
          </g>
        ))}
      </svg>
    );
  }
  if (kind === "map") {
    return (
      <svg viewBox="0 0 320 180" width={w} height={h} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        <path d="M20 140 Q 80 50, 160 90 T 300 60" stroke="#3d3a39" strokeWidth="1" fill="none" strokeDasharray="4 4"/>
        <path d="M20 140 Q 80 50, 160 90" stroke="#00d992" strokeWidth="2" fill="none"/>
        {[[20, 140], [85, 95], [160, 90], [240, 70], [300, 60]].map(([x, y], i) => (
          <g key={i}>
            <circle cx={x} cy={y} r="6" fill="#00d992" opacity=".2"/>
            <circle cx={x} cy={y} r="3" fill={i < 3 ? "#00d992" : "#3d3a39"}/>
          </g>
        ))}
      </svg>
    );
  }
  // sparkline default
  return (
    <svg viewBox="0 0 320 180" width={w} height={h} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
      {Array.from({ length: 5 }).map((_, r) => (
        <g key={r} transform={`translate(0, ${30 + r * 28})`}>
          <text x="20" y="0" fontFamily="JetBrains Mono" fontSize="9" fill="#6b6664">node-{(r+1).toString().padStart(2,"0")}</text>
          <line x1="80" y1="0" x2="280" y2="0" stroke="#1a1a1a"/>
          <path d={`M80 0 ${Array.from({ length: 8 }).map((_, i) => {
            const off = ((r * 3 + i * 5) % 11) - 5;
            return "L" + (80 + (i+1) * 25) + " " + (off);
          }).join(" ")}`} stroke={r === 2 ? "#00d992" : "#3d3a39"} strokeWidth="1.5" fill="none"/>
        </g>
      ))}
    </svg>
  );
}

Object.assign(window, { PortfolioPage, PROJECTS, ProjectThumb });
